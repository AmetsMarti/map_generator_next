
"use client";
import Button from "./components/Button";
import MapDisplay from "./mapDisplay";
import { useState } from "react";
import {IslandGenerator, Map} from "./mapFunctions";

export default function Selector() {
    const [mapSeed, setMapSeed] = useState(0);
    let map = new Map(30, 30);
    let islandGenerator = new IslandGenerator([0, 0], map);

    return (
        <div className="flex flex-col gap-4">
            <h1>Map Generator</h1>
            <MapDisplay map={map}/>
            <Button onClick={islandGenerator.generateIsland(1200,islandGenerator.position)} className="bg-purple-900 hover:bg-purple-800 text-white font-bold py-2 px-4 rounded cursor-pointer m-2 bg-center">
                Generate
            </Button>
        </div>
    );
}